About Entropica Labs
====================
 
Entropica Labs is a Singapore-based team of physicists and computer scientists developing tools and applications for quantum computing. We create software and design algorithms to enable practical and scalable near-term quantum machine learning and optimisation. 

To learn more about us, visit `entropicalabs.com <https://entropicalabs.com/>`_, take a look at our `blog <https://medium.com/@entropicalabs>`_, or contact us at info@entropicalabs.com.